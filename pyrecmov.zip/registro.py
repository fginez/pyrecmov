__author__ = 'ginezf'
from janela import *
from padrao import *
from resultado import *

class Registro:

    def __init__(self):
        self.janela = []
        self.padrao = []
        self.resultado = []
        pass
