__author__ = 'ginezf'
from classif import *


class Classificador:

    def __init__(self):
        pass

    def classifica(self, padrao):
        pass